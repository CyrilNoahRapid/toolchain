/*****************************************************************************/
/* DECODE.H - Prototypes for name mangling code in DECODE.C.                 */
/*****************************************************************************/

#ifndef _DECODE_H
#define _DECODE_H

/*----------------------------------------------------------------------------*/
/* VARIABLE USED TO SELECT DEMANGLING SCHEME USED BY THE THREE USER VISIBLE   */
/* DECODE ROUTINES - decode_to_decorid, decode_to_origid AND decode_id.       */
/* DEFAULT VALUE IS msk_edg. ANY TOOL THAT INVOKES THESE FUNCTION IN EABI     */
/* MODE SHOULD SET decode_mangle_scheme TO msk_ia64                           */
/*----------------------------------------------------------------------------*/
typedef enum { msk_edg=0, msk_ia64 } MANGLE_STYLE_KIND;
extern MANGLE_STYLE_KIND decode_mangle_scheme;

void decode_to_decorid(const char   *id,
                       char         *output_buffer,
                       size_t        output_buffer_size,
                       int          *err,
                       int          *buffer_overflow_err,
                       size_t       *required_buffer_size);

/*----------------------------------------------------------------------------*/
/* IA64 VERSION OF ROUTINE DOES NOT PUT OUT FUNCTION PARAMETERS - OTHERWISE   */
/* IDENTICAL TO decode_to_decorid                                             */
/*----------------------------------------------------------------------------*/
void decode_to_origid(const char   *id,
                      char         *output_buffer,
                      size_t        output_buffer_size,
                      int          *err,
                      int          *buffer_overflow_err,
                      size_t       *required_buffer_size);

/*----------------------------------------------------------------------------*/
/* IA64 VERSION INCLUDES PARTIAL SUPPORT FOR decorated==FALSE - THE FUNCTION  */
/* PARAMETERS ARE NOT RETURNED AS PART OF DEMANGLING WHEN decorated IS FALSE  */
/*----------------------------------------------------------------------------*/
const char *decode_id(const char *id, int decorated);

#endif
