// EXPORTED FUNCTIONS
#include <iosfwd>
_STD_BEGIN

template<class _Elem>
	int char_traits<_Elem>::compare(const _Elem *_First1,
	const _Elem *_First2, size_t _Count)
	{	// compare [_First1, _First1 + _Count) with [_First2, ...)
//		_DEBUG_POINTER(_First1);
//		_DEBUG_POINTER(_First2);
	for (; 0 < _Count; --_Count, ++_First1, ++_First2)
		if (!eq(*_First1, *_First2))
			return (lt(*_First1, *_First2) ? -1 : +1);
	return (0);
	}

template<class _Elem>
	size_t char_traits<_Elem>::length(const _Elem *_First)
	{	// find length of null-terminated sequence
//		_DEBUG_POINTER(_First);
	size_t _Count;
	for (_Count = 0; !eq(*_First, _Elem()); ++_First)
		++_Count;
	return (_Count);
	}

template<class _Elem>
	_Elem *char_traits<_Elem>::copy(_Elem *_First1,
	const _Elem *_First2, size_t _Count)
	{	// copy [_First1, _First1 + _Count) to [_First2, ...)
//		_DEBUG_POINTER(_First1);
//		_DEBUG_POINTER(_First2);
	_Elem *_Next = _First1;
	for (; 0 < _Count; --_Count, ++_Next, ++_First2)
		assign(*_Next, *_First2);
	return (_First1);
	}

template<class _Elem>
	const _Elem *char_traits<_Elem>::find(const _Elem *_First,
	size_t _Count, const _Elem& _Ch)
	{	// look for _Ch in [_First, _First + _Count)
//		_DEBUG_POINTER(_First);
	for (; 0 < _Count; --_Count, ++_First)
		if (eq(*_First, _Ch))
			return (_First);
	return (0);
	}

template<class _Elem>
	_Elem *char_traits<_Elem>::move(_Elem *_First1,
	const _Elem *_First2, size_t _Count)
	{	// copy [_First1, _First1 + _Count) to [_First2, ...)
//		_DEBUG_POINTER(_First1);
//		_DEBUG_POINTER(_First2);
	_Elem *_Next = _First1;
	if (_First2 < _Next && _Next < _First2 + _Count)
		for (_Next += _Count, _First2 += _Count; 0 < _Count; --_Count)
			assign(*--_Next, *--_First2);
	else
		for (; 0 < _Count; --_Count, ++_Next, ++_First2)
			assign(*_Next, *_First2);
	return (_First1);
	}

template<class _Elem>
	_Elem *char_traits<_Elem>::assign(_Elem *_First,
	size_t _Count, _Elem _Ch)
	{	// assign _Count * _Ch to [_First, ...)
//		_DEBUG_POINTER(_First);
	_Elem *_Next = _First;
	for (; 0 < _Count; --_Count, ++_Next)
		assign(*_Next, _Ch);
	return (_First);
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
