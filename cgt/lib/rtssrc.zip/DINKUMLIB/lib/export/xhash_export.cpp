// EXPORTED FUNCTIONS
#include <xhash>
_STD_BEGIN

template<class _Elem,
	class _Traits,
	class _Alloc>
	size_t hash_value(const basic_string<_Elem, _Traits, _Alloc>& _Str)
	{	// hash string to size_t value
	return (_Hash_value(_Str.begin(), _Str.end()));
	}

template<class _Traits>
	typename _Hash<_Traits>::_Pairib _Hash<_Traits>::insert(const value_type& _Val)
	{	// try to insert node with value _Val
	iterator _Plist, _Where;
	if (_Maxidx <= size() / bucket_size)
		{	// too dense, need to grow hash table
		if (_Vec.size() - 1 <= _Maxidx)
			{	// table full, double its size
			_Mask = ((_Vec.size() - 1) << 1) - 1;
			_Vec.resize(_Mask + 2, end());
			}
		else if (_Mask < _Maxidx)
			_Mask = (_Mask << 1) + 1;

		size_type _Bucket = _Maxidx - (_Mask >> 1) - 1;
		for (_Plist = _Vec[_Bucket]; _Plist != _Vec[_Bucket + 1]; )
			{	// split old bucket
			size_type _Newbucket =
				this->comp(this->_Kfn(*_Plist)) & _Mask;
			if (_Newbucket == _Bucket)
				++_Plist;	// leave element in old bucket

 #if _HAS_ITERATOR_DEBUGGING
			else if (_Newbucket != _Maxidx)
				_DEBUG_ERROR("bad hash function");
 #endif /* _HAS_ITERATOR_DEBUGGING */

			else
				{	// move element to new bucket
				size_type _Idx;
				iterator _Pnext = _Plist;
				if (++_Pnext != end())
					{	// not at end, move it
					for (_Idx = _Bucket; _Plist == _Vec[_Idx]; --_Idx)
						{	// update end iterators if moving first
						_Vec[_Idx] = _Pnext;
						if (_Idx == 0)
							break;
						}
					_List._Splice(end(), _List, _Plist, _Pnext, 0);
					_Plist = --end();
					_Vec[_Maxidx + 1] = end();
					}

				for (_Idx = _Maxidx; _Bucket < _Idx; --_Idx)
					{	// update end iterators if new bucket filled
					if (_Vec[_Idx] != end())
						break;
					_Vec[_Idx] = _Plist;
					}

				if (_Pnext == end())
					break;
				else
					_Plist = _Pnext;
				}
			}
		++_Maxidx;	// open new bucket for hash lookup
		}

	size_type _Bucket = _Hashval(this->_Kfn(_Val));
	for (_Plist = _Vec[_Bucket + 1]; _Plist != _Vec[_Bucket]; )
		if (this->comp(this->_Kfn(_Val), this->_Kfn(*--_Plist)))
			;	// still too high in bucket list
		else if (this->comp(this->_Kfn(*_Plist), this->_Kfn(_Val)))
			{	// found insertion point, back up to it
			++_Plist;
			break;
			}
		else if (_Multi)
			break;	// equivalent, insert only if multi
		else
			return (_Pairib(_Plist, false));	// already present

	_Where = _List.insert(_Plist, _Val);	// insert new element
	for (; _Plist == _Vec[_Bucket]; --_Bucket)
		{	// update end iterators if new first bucket element
		_Vec[_Bucket] = _Where;
		if (_Bucket == 0)
			break;
		}

	return (_Pairib(_Where, true));	// return iterator for new element
	}

template<class _Traits>
	template<class _Iter>
	void _Hash<_Traits>::insert(_Iter _First, _Iter _Last)
	{	// insert [_First, _Last) one at a time

 #if _HAS_ITERATOR_DEBUGGING
	_DEBUG_RANGE(_First, _Last);
	if (_Debug_get_cont(_First) == this)
		_DEBUG_ERROR("hash_map/set insertion overlaps range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	for (; _First != _Last; ++_First)
		insert(*_First);
	}

template<class _Traits>
	typename _Hash<_Traits>::iterator _Hash<_Traits>::erase(iterator _Where)
	{	// erase element at _Where
	size_type _Bucket = _Hashval(this->_Kfn(*_Where));
	for (; _Where == _Vec[_Bucket]; --_Bucket)
		{	// update end iterators if erasing first
		++_Vec[_Bucket];
		if (_Bucket == 0)
			break;
		}
	return (_List.erase(_Where));
	}

template<class _Traits>
	typename _Hash<_Traits>::iterator _Hash<_Traits>::erase(iterator _First, iterator _Last)
	{	// erase [_First, _Last)
	_DEBUG_RANGE(_First, _Last);
	if (_First == begin() && _Last == end())
		{	// erase all
		clear();
		return (begin());
		}
	else
		{	// partial erase, one at a time
		while (_First != _Last)
			erase(_First++);
		return (_First);
		}
	}

template<class _Traits>
	typename _Hash<_Traits>::size_type _Hash<_Traits>::erase(const key_type& _Keyval)
	{	// erase and count all that match _Keyval
	_Pairii _Where = equal_range(_Keyval);
	size_type _Num = 0;
	_Distance(_Where.first, _Where.second, _Num);
	erase(_Where.first, _Where.second);
	return (_Num);
	}

template<class _Traits>
	void _Hash<_Traits>::erase(const key_type *_First,
	const key_type *_Last)
	{	// erase all that match array of keys [_First, _Last)
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		erase(*_First);
	}

template<class _Traits>
	typename _Hash<_Traits>::size_type _Hash<_Traits>::count(const key_type& _Keyval) const
	{	// count all elements that match _Keyval
	_Paircc _Ans = equal_range(_Keyval);
	size_type _Num = 0;
	_Distance(_Ans.first, _Ans.second, _Num);
	return (_Num);
	}

template<class _Traits>
	typename _Hash<_Traits>::iterator _Hash<_Traits>::lower_bound(const key_type& _Keyval)
	{	// find leftmost not less than _Keyval in mutable hash table
	size_type _Bucket = _Hashval(_Keyval);
	iterator _Where;
	for (_Where = _Vec[_Bucket]; _Where != _Vec[_Bucket + 1]; ++_Where)
		if (!this->comp(this->_Kfn(*_Where), _Keyval))
			return (this->comp(_Keyval,
				this->_Kfn(*_Where)) ? end() : _Where);
	return (end());
	}

template<class _Traits>
	typename _Hash<_Traits>::const_iterator _Hash<_Traits>::lower_bound(const key_type& _Keyval) const
	{	// find leftmost not less than _Keyval in nonmutable hash table
	size_type _Bucket = _Hashval(_Keyval);
	const_iterator _Where;
	for (_Where = _Vec[_Bucket]; _Where != _Vec[_Bucket + 1]; ++_Where)
		if (!this->comp(this->_Kfn(*_Where), _Keyval))
			return (this->comp(_Keyval,
				this->_Kfn(*_Where)) ? end() : _Where);
	return (end());
	}

template<class _Traits>
	typename _Hash<_Traits>::iterator _Hash<_Traits>::upper_bound(const key_type& _Keyval)
	{	// find leftmost not greater than _Keyval in mutable hash table
	size_type _Bucket = _Hashval(_Keyval);
	iterator _Where;
	for (_Where = _Vec[_Bucket + 1]; _Where != _Vec[_Bucket]; )
		if (!this->comp(_Keyval, this->_Kfn(*--_Where)))
			return (this->comp(this->_Kfn(*_Where),
				_Keyval) ? end() : (iterator)++_Where);
	return (end());
	}

template<class _Traits>
	typename _Hash<_Traits>::const_iterator _Hash<_Traits>::upper_bound(const key_type& _Keyval) const
	{	// find leftmost not greater than _Keyval in nonmutable hash table
	size_type _Bucket = _Hashval(_Keyval);
	const_iterator _Where;
	for (_Where = _Vec[_Bucket + 1]; _Where != _Vec[_Bucket]; )
		if (!this->comp(_Keyval, this->_Kfn(*--_Where)))
			return (this->comp(this->_Kfn(*_Where),
				_Keyval) ? end() : (const_iterator)++_Where);
	return (end());
	}

template<class _Traits>
	typename _Hash<_Traits>::_Pairii _Hash<_Traits>::equal_range(const key_type& _Keyval)
	{	// find range equivalent to _Keyval in mutable hash table
	size_type _Bucket = _Hashval(_Keyval);
	iterator _First, _Where;
	for (_Where = _Vec[_Bucket]; _Where != _Vec[_Bucket + 1]; ++_Where)
		if (!this->comp(this->_Kfn(*_Where), _Keyval))
			{	// found _First, look for end of range
			for (_First = _Where; _Where != _Vec[_Bucket + 1]; ++_Where)
				if (this->comp(_Keyval, this->_Kfn(*_Where)))
					break;
			if (_First == _Where)
				break;
			return (_Pairii(_First, _Where));
			}
	return (_Pairii(end(), end()));
	}

template<class _Traits>
	typename _Hash<_Traits>::_Paircc _Hash<_Traits>::equal_range(const key_type& _Keyval) const
	{	// find range equivalent to _Keyval in nonmutable hash table
	size_type _Bucket = _Hashval(_Keyval);
	iterator _First, _Where;
	for (_Where = _Vec[_Bucket]; _Where != _Vec[_Bucket + 1]; ++_Where)
		if (!this->comp(this->_Kfn(*_Where), _Keyval))
			{	// found _First, look for end of range
			for (_First = _Where; _Where != _Vec[_Bucket + 1]; ++_Where)
				if (this->comp(_Keyval, this->_Kfn(*_Where)))
					break;
			if (_First == _Where)
				break;
			return (_Paircc(_First, _Where));
			}
	return (_Paircc(end(), end()));
	}

template<class _Traits>
	typename _Hash<_Traits>::size_type _Hash<_Traits>::elems_in_bucket(size_type _Bucket) const
{	// return number of elements in bucket
size_type _Ans = 0;
if (_Bucket < _Maxidx)
	for (iterator _Plist = _Vec[_Bucket];
		_Plist != _Vec[_Bucket + 1]; ++_Plist)
		++_Ans;
return (_Ans); }

template<class _Traits>
	void _Hash<_Traits>::_Copy(const _Myt& _Right)
	{	// copy entire hash table
	_Vec.resize(_Right._Vec.size(), end());
	_Mask = _Right._Mask;
	_Maxidx = _Right._Maxidx;
	_List.clear();

	_TRY_BEGIN
	_List.insert(end(), _Right._List.begin(), _Right._List.end());
	this->comp = _Right.comp;
	_CATCH_ALL
	_List.clear();	// list or compare copy failed, bail out
	fill(_Vec.begin(), _Vec.end(), end());
	_RERAISE;
	_CATCH_END

	iterator _Whereto = begin();
	const_iterator _Wherefrom = _Right.begin();
	for (size_type _Bucket = 0; _Bucket < _Vec.size(); )
		if (_Wherefrom == _Right._Vec[_Bucket])
			_Vec[_Bucket] = _Whereto, ++_Bucket;
		else
			++_Whereto, ++_Wherefrom;
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
