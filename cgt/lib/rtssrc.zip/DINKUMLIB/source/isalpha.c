/* isalpha function */
#if defined(__TI_COMPILER_VERSION__)
#undef _INLINE
#endif /* defined(__TI_COMPILER_VERSION__) */
#include <ctype.h>
_STD_BEGIN

int (isalpha)(int c)
	{	/* test for alphabetic character */
	return (_Getchrtype(c) & (_LO | _UP | _XA));
	}
_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
