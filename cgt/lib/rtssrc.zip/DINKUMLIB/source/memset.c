/* memset function */

#if defined(__TI_COMPILER_VERSION__)
#undef _INLINE
#include <string.h>
#if defined(_TMS320C6400) || defined(_TMS320C6740)
void *memset(void *dst, int fill, size_t len)
{   
       char  *restrict dst1, *restrict dst2;
       int    pre_bytes, post_bytes, wfill, i;
       double dfill1, dfill2;

       dst1   = (char *)dst;

       /*--------------------------------------------------------------------*/
       /* Replicate the 8-bit value in fill into all 4 bytes of wfill        */
       /*--------------------------------------------------------------------*/
       wfill  = _pack2 (fill,  fill);
       wfill  = _packl4(wfill, wfill); 
       dfill1 = _itod  (wfill, wfill);
       dfill2 = _itod  (wfill, wfill);

       /*--------------------------------------------------------------------*/
       /* Calculate number of bytes to pre-copy to get to an alignment of 8  */
       /*--------------------------------------------------------------------*/
       pre_bytes = (8 - (int) dst) & 7;

       if (len > pre_bytes)
       {
           len -= pre_bytes;
           if (pre_bytes & 1) { *dst1        = fill;  dst1 += 1; }
           if (pre_bytes & 2) { _amem2(dst1) = wfill; dst1 += 2; }
           if (pre_bytes & 4) { _amem4(dst1) = wfill; dst1 += 4; }
       }

       /*--------------------------------------------------------------------*/
       /* Double word fills                                                  */
       /*--------------------------------------------------------------------*/
       post_bytes = len > 0 ? len : 0;   
       dst2       = dst1 + 8;

       if (len > 15)
         for (i = 0; i < len >> 4; i++)
         {
            _amemd8(dst1) = dfill1; dst1 += 16;
            _amemd8(dst2) = dfill2; dst2 += 16;
            post_bytes -= 16;
         }

       /*--------------------------------------------------------------------*/
       /* Finish transfer with 8, 4, 2 and/or 1-byte writes                  */
       /*--------------------------------------------------------------------*/
       if (post_bytes & 8) { _memd8(dst1) = dfill1; dst1 += 8; }
       if (post_bytes & 4) { _mem4 (dst1) = wfill;  dst1 += 4; }
       if (post_bytes & 2) {  dst1[0]     = wfill;  
                              dst1[1]     = wfill;  dst1 += 2; }
       if (post_bytes & 1) { *dst1        = fill;   dst1 += 1; }
       return dst;
}
#else /* defined(_TMS320C6400) || defined(_TMS320C6740) */
void *memset(void *dst, int fill, size_t len)
{   
       char  *restrict dst1, *restrict dst2;
       int    pre_bytes, post_bytes, wfill, i;

       dst1   = (char *)dst;

       /*--------------------------------------------------------------------*/
       /* Replicate the 8-bit value in fill into all 4 bytes of wfill        */
       /*--------------------------------------------------------------------*/
       wfill  = _mpy(0x101, fill & 0xff);
       wfill += wfill << 16;

       /*--------------------------------------------------------------------*/
       /* Calculate number of bytes to pre-copy to get to an alignment of 4  */
       /*--------------------------------------------------------------------*/
       pre_bytes = (4 - (int) dst) & 3;

       if (len > pre_bytes)
       {
           len -= pre_bytes;
           if (pre_bytes & 1) { *dst1        = fill;  dst1 += 1; }
           if (pre_bytes & 2) { _amem2(dst1) = wfill; dst1 += 2; }
       }

       /*--------------------------------------------------------------------*/
       /* Double word fills                                                  */
       /*--------------------------------------------------------------------*/
       post_bytes = len > 0 ? len : 0;   
       dst2       = dst1 + 4;

       if (len > 7)
         for (i = 0; i < len >> 3; i++)
         {
            _amem4(dst1) = wfill; dst1 += 8;
            _amem4(dst2) = wfill; dst2 += 8;
            post_bytes -= 8;
         }

       /*--------------------------------------------------------------------*/
       /* Finish transfer with 8, 4, 2 and/or 1-byte writes                  */
       /*--------------------------------------------------------------------*/
       if (post_bytes) { *dst1++ = fill; post_bytes--; }
       if (post_bytes) { *dst1++ = fill; post_bytes--; }
       if (post_bytes) { *dst1++ = fill; post_bytes--; }
       if (post_bytes) { *dst1++ = fill; post_bytes--; }
       if (post_bytes) { *dst1++ = fill; post_bytes--; }
       if (post_bytes) { *dst1++ = fill; post_bytes--; }
       if (post_bytes) { *dst1++ = fill; post_bytes--; }
       return dst;
}
#endif /* defined(_TMS320C6400) || defined(_TMS320C6740) */
#else /* defined(__TI_COMPILER_VERSION__) */
#include <string.h>
_STD_BEGIN

void *(memset)(void *s, int c, size_t n)
	{	/* store c throughout unsigned char s[n] */
	const unsigned char uc = (unsigned char)c;
	unsigned char *su = (unsigned char *)s;

	for (; 0 < n; ++su, --n)
		*su = uc;
	return (s);
	}
_STD_END
#endif /* defined(__TI_COMPILER_VERSION__) */
/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
